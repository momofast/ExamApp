package fr.astek.testexam.entity;

public enum Difficulte {
 debutant,
 intermediaire,
 expert
}
